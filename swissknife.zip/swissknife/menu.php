<nav class="navbar bg-primary">
  <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="/swissknife/index.php">Back to menu</a>
          <body>
  </div>
</nav>