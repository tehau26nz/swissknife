<div class="text-center" id="currentStateOfPlay">
    <h1><?php echo $currentStateOfPlay; ?></h1>
</div>