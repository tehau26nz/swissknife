<div class="alert alert-success text-center" role="alert">
    HOORAY! You've won!
</div>
<div class="text-center">
    <a href="hangman.php" class="btn btn-success" role="button">Want to play again?</a>
</div>