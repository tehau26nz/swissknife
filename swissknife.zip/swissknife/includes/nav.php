 <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="index.php">My Swiss Knife</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="hangman.php">Game</a></li>
            <li><a href="flicks.php">CRUD app</a></li>
            <li><a href="mywebsite.php">About</a></li>

           
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>