<div class="alert alert-dismissible alert-warning fade show text-center mt-3">
  <button type="button" class="btn-close" data-dismiss="alert"></button>
  <p class="mb-0"><?php echo $message; ?></p>
</div>